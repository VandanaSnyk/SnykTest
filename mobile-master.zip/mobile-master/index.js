require('./src/index.ts');
