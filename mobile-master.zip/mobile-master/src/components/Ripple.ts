import MaterialRipple, {Props as MaterialRippleProps} from 'react-native-material-ripple';

export type RippleProps = MaterialRippleProps;

export const Ripple = MaterialRipple;
