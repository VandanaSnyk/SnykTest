// generate-translations.js
const {generateTranslationDictionaries} = require('@shopify/react-i18n/generate-dictionaries');

generateTranslationDictionaries(['en', 'fr']);
